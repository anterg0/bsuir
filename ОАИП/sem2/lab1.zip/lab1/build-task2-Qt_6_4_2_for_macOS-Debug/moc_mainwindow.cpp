/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../task2/mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MainWindow_t {
    uint offsetsAndSizes[52];
    char stringdata0[11];
    char stringdata1[22];
    char stringdata2[1];
    char stringdata3[22];
    char stringdata4[6];
    char stringdata5[19];
    char stringdata6[24];
    char stringdata7[32];
    char stringdata8[24];
    char stringdata9[24];
    char stringdata10[21];
    char stringdata11[34];
    char stringdata12[17];
    char stringdata13[5];
    char stringdata14[24];
    char stringdata15[24];
    char stringdata16[32];
    char stringdata17[21];
    char stringdata18[22];
    char stringdata19[24];
    char stringdata20[24];
    char stringdata21[24];
    char stringdata22[25];
    char stringdata23[24];
    char stringdata24[5];
    char stringdata25[25];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MainWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 21),  // "on_pushButton_clicked"
        QT_MOC_LITERAL(33, 0),  // ""
        QT_MOC_LITERAL(34, 21),  // "on_comboBox_activated"
        QT_MOC_LITERAL(56, 5),  // "index"
        QT_MOC_LITERAL(62, 18),  // "on_addBook_clicked"
        QT_MOC_LITERAL(81, 23),  // "on_pushButton_2_clicked"
        QT_MOC_LITERAL(105, 31),  // "on_comboBox_currentIndexChanged"
        QT_MOC_LITERAL(137, 23),  // "on_pushButton_4_clicked"
        QT_MOC_LITERAL(161, 23),  // "on_pushButton_3_clicked"
        QT_MOC_LITERAL(185, 20),  // "on_addReader_clicked"
        QT_MOC_LITERAL(206, 33),  // "on_listWidget_2_itemDoubleCli..."
        QT_MOC_LITERAL(240, 16),  // "QListWidgetItem*"
        QT_MOC_LITERAL(257, 4),  // "item"
        QT_MOC_LITERAL(262, 23),  // "on_pushButton_5_clicked"
        QT_MOC_LITERAL(286, 23),  // "on_pushButton_6_clicked"
        QT_MOC_LITERAL(310, 31),  // "on_listWidget_itemDoubleClicked"
        QT_MOC_LITERAL(342, 20),  // "on_Debters_triggered"
        QT_MOC_LITERAL(363, 21),  // "on_bookList_triggered"
        QT_MOC_LITERAL(385, 23),  // "on_pushButton_7_clicked"
        QT_MOC_LITERAL(409, 23),  // "on_pushButton_8_clicked"
        QT_MOC_LITERAL(433, 23),  // "on_pushButton_9_clicked"
        QT_MOC_LITERAL(457, 24),  // "on_pushButton_10_clicked"
        QT_MOC_LITERAL(482, 23),  // "on_lineEdit_textChanged"
        QT_MOC_LITERAL(506, 4),  // "arg1"
        QT_MOC_LITERAL(511, 24)   // "on_pushButton_11_clicked"
    },
    "MainWindow",
    "on_pushButton_clicked",
    "",
    "on_comboBox_activated",
    "index",
    "on_addBook_clicked",
    "on_pushButton_2_clicked",
    "on_comboBox_currentIndexChanged",
    "on_pushButton_4_clicked",
    "on_pushButton_3_clicked",
    "on_addReader_clicked",
    "on_listWidget_2_itemDoubleClicked",
    "QListWidgetItem*",
    "item",
    "on_pushButton_5_clicked",
    "on_pushButton_6_clicked",
    "on_listWidget_itemDoubleClicked",
    "on_Debters_triggered",
    "on_bookList_triggered",
    "on_pushButton_7_clicked",
    "on_pushButton_8_clicked",
    "on_pushButton_9_clicked",
    "on_pushButton_10_clicked",
    "on_lineEdit_textChanged",
    "arg1",
    "on_pushButton_11_clicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  134,    2, 0x08,    1 /* Private */,
       3,    1,  135,    2, 0x08,    2 /* Private */,
       5,    0,  138,    2, 0x08,    4 /* Private */,
       6,    0,  139,    2, 0x08,    5 /* Private */,
       7,    1,  140,    2, 0x08,    6 /* Private */,
       8,    0,  143,    2, 0x08,    8 /* Private */,
       9,    0,  144,    2, 0x08,    9 /* Private */,
      10,    0,  145,    2, 0x08,   10 /* Private */,
      11,    1,  146,    2, 0x08,   11 /* Private */,
      14,    0,  149,    2, 0x08,   13 /* Private */,
      15,    0,  150,    2, 0x08,   14 /* Private */,
      16,    1,  151,    2, 0x08,   15 /* Private */,
      17,    0,  154,    2, 0x08,   17 /* Private */,
      18,    0,  155,    2, 0x08,   18 /* Private */,
      19,    0,  156,    2, 0x08,   19 /* Private */,
      20,    0,  157,    2, 0x08,   20 /* Private */,
      21,    0,  158,    2, 0x08,   21 /* Private */,
      22,    0,  159,    2, 0x08,   22 /* Private */,
      23,    1,  160,    2, 0x08,   23 /* Private */,
      25,    0,  163,    2, 0x08,   25 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   24,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSizes,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_comboBox_activated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_addBook_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_comboBox_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_pushButton_4_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_addReader_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_listWidget_2_itemDoubleClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'on_pushButton_5_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_6_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_listWidget_itemDoubleClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'on_Debters_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_bookList_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_7_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_8_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_9_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_10_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_lineEdit_textChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_pushButton_11_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_pushButton_clicked(); break;
        case 1: _t->on_comboBox_activated((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->on_addBook_clicked(); break;
        case 3: _t->on_pushButton_2_clicked(); break;
        case 4: _t->on_comboBox_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->on_pushButton_4_clicked(); break;
        case 6: _t->on_pushButton_3_clicked(); break;
        case 7: _t->on_addReader_clicked(); break;
        case 8: _t->on_listWidget_2_itemDoubleClicked((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 9: _t->on_pushButton_5_clicked(); break;
        case 10: _t->on_pushButton_6_clicked(); break;
        case 11: _t->on_listWidget_itemDoubleClicked((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 12: _t->on_Debters_triggered(); break;
        case 13: _t->on_bookList_triggered(); break;
        case 14: _t->on_pushButton_7_clicked(); break;
        case 15: _t->on_pushButton_8_clicked(); break;
        case 16: _t->on_pushButton_9_clicked(); break;
        case 17: _t->on_pushButton_10_clicked(); break;
        case 18: _t->on_lineEdit_textChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 19: _t->on_pushButton_11_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 20;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
